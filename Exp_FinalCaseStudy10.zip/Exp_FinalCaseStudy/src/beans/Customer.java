package beans;

public class Customer {
	
	String cid;
	String cname;
	String email;
	int mobno;


	public Customer(int mobno, String cid, String cname, String email) {
		super();
		this.mobno = mobno;
		this.cid = cid;
		this.cname = cname;
		this.email = email;
	}
	public String getCid() {
		return cid;
	}
	public String getCname() {
		return cname;
	}
	public String getEmail() {
		return email;
	}
	public int getmobno() {
		return mobno;
	}

	

}
