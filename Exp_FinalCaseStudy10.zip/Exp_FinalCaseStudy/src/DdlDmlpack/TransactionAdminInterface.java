package DdlDmlpack;

import java.util.ArrayList;

import beans.SearchTrans;
import beans.Transaction;

public interface TransactionAdminInterface {
	
	public int AddTransaction(Transaction ts);
	public int ModifyTransaction(String id,String col,String val);
	public int DeleteTransaction(String id);
	public double checkLimit(String plan);
	public ArrayList<Transaction> SearchTrans(SearchTrans st);
	

}
