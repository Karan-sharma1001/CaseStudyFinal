package validation;

import java.sql.*;

import beans.Customer;
import beans.JdbcConnection;

public class RegisterImpl implements Register{


	public String register(Customer c) {
		String res=null;
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		ResultSet rs1;
		PreparedStatement pst1;
		
		JdbcConnection db=new JdbcConnection();
		con=db.getConnection();
		 try {
			pst1=con.prepareStatement("select plantype from Userdetail where customerid=?");
			pst1.setString(1, c.getCid());
			rs1=pst1.executeQuery();
			String plan=rs1.getString(1);
			pst=con.prepareStatement("insert into userdetail values(?,?,?,?,?)");
			pst.setString(1, c.getCid());
			pst.setString(2, c.getCname());
			pst.setString(3, c.getEmail());
			pst.setInt(4, c.getmobno());
			pst.setString(5, plan);
			rs=pst.executeQuery();
			if(rs.next()){
				res="found";
			}
			else{
				res="notfound";				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 
		
		
		return res;
	}

}
