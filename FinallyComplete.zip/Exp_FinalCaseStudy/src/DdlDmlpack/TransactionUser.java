package DdlDmlpack;

import java.util.ArrayList;

import beans.SearchTrans;
import beans.Transaction;



public interface TransactionUser {
	
	public ArrayList<Transaction> userTrans(String id,SearchTrans st);
	
	

}
