  
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import validation.LoginValidateImpl;
import validation.RegisterImpl;
import validation.TransactionValidateImpl;
import DdlDmlpack.GenerateBillImpl;
import DdlDmlpack.Registercustomer;
import DdlDmlpack.TransUserimpl;
import DdlDmlpack.Transactionadmin;
import beans.Customer;
import beans.Bill;
import beans.JdbcConnection;
import beans.Login;
import beans.SearchTrans;
import beans.Transaction;

/**
 * Servlet implementation class CreditController
 */
public class CreditController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PrintWriter pw;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CreditController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		LoginValidateImpl login=new LoginValidateImpl();
		
		String operation=request.getParameter("operation");

		if(operation.equalsIgnoreCase("userlogin")){

			this.userLogin(request,response);
		
		}
		if(operation.equalsIgnoreCase("register")){
			this.register(request,response);
			
		}

		if(operation.equalsIgnoreCase("logout")){
			session.invalidate();
			response.sendRedirect("Logout.jsp");
			
		}

		if(operation.equalsIgnoreCase("adminlogin")){
			this.adminLogin(request,response);
			
		}

		if(operation.equalsIgnoreCase("viewcard")){
			this.viewCard(request,response);
			

		}
		if(operation.equalsIgnoreCase("addtrans")){
			this.addTrans(request,response);
			

		}
		if(operation.equalsIgnoreCase("modtrans")){

			this.modTrans(request,response);
		}
		if(operation.equalsIgnoreCase("deltrans")){
			delTrans(request,response);

		}

		if(operation.equalsIgnoreCase("getbill")){
			getBill(request,response);

		}

		if(operation.equalsIgnoreCase("transuser")){

			transUser(request,response);

		}

		if(operation.equalsIgnoreCase("viewcust")){

			custinfo(request,response);
		}

		if(operation.equalsIgnoreCase("resetpass")){
			Connection con;
			PreparedStatement pst;
			Statement st;
			ResultSet rs;
			PrintWriter pw=response.getWriter();
			JdbcConnection db=new JdbcConnection();
			con=db.getConnection();
			String id=(request.getParameter("lid"));
			String old=request.getParameter("pwd1");
			String newp=request.getParameter("pwd2");
			String confnew=request.getParameter("pwd3");
			String val=null;;
		
				try {
					st=con.createStatement();
					rs=st.executeQuery("select password from customerlogin where userid='"+id+"'");
					if(rs.next()){
						if(rs.getString(1).equals(old)){
							val="valid";
						}
						else{
							val="invalid";
						}
					}
					rs.close();st.close();
					if(val.equals("valid")){
						if(newp.equals(confnew)){
							pst=con.prepareStatement("update customerlogin set password=? where userid=?");
							pst.setString(1, newp);
							pst.setString(2,id);
							int n=pst.executeUpdate();
							if(n>0){
								pw.println("* Password changed....");
								RequestDispatcher rd=request.getRequestDispatcher("Customerlogin.jsp");
								rd.include(request, response);
							}
							pst.close();con.close();
							
						}
						else{
							pw.println("<font color=red>* Passwords didnt match....</font>");
							RequestDispatcher rd=request.getRequestDispatcher("Customerlogin.jsp");
							rd.include(request, response);
							
						}
					}else{
						pw.println("<font color=red>* Old password is incorrect..</font>");
						RequestDispatcher rd=request.getRequestDispatcher("Customerlogin.jsp");
						rd.include(request, response);
						
					}
					pw.close();rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
		
		if(operation.equalsIgnoreCase("searchtrans")){

			String value=request.getParameter("radio1");
			String name=request.getParameter("value");
			HttpSession hs=request.getSession();


			SearchTrans st=new SearchTrans();
			st.setColumn(value);
			st.setValue(name);

			Transactionadmin ta=new Transactionadmin();
			ArrayList<Transaction> t=ta.SearchTrans(st);


			hs.setAttribute("searchtrans", t);
			RequestDispatcher rd=request.getRequestDispatcher("Details.jsp");				
			rd.forward(request, response);




		}
	}









	private void custinfo(HttpServletRequest request,
			HttpServletResponse response) {
		Connection con;
		Statement st;
		ResultSet rs;
		HttpSession hs=request.getSession();
		JdbcConnection db=new JdbcConnection();
		con=db.getConnection();
		try {
			pw=response.getWriter();
			st=con.createStatement();
			rs=st.executeQuery("select * from userdetail");
			pw.println("<body bgcolor=lightblue>");
			pw.println("<div><center><font size=6 color=blue>GLOBAL BANK</font><br/><font size=4 color=black><b><u>CREDIT CARD MANAGEMENT</u></b></font></div>");

			
			pw.println("<br/><br/><br/><center><font size=4>Logged in as admin "+hs.getAttribute("admin")+"</font></center><br/><br/><br/>");
			pw.println("<br/><br/><center><h3><u>CUSTOMER DETAILS</u></h3>");
			pw.println("<table border=1><tr><th>CUSTOMER ID</th><th>NAME</th><th>EMAIL</th><th>MOB NO</th><th>PLAN</th></tr>");
			while(rs.next()){
				pw.println("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getInt(4)+"</td><td>"+rs.getString(5)+"</td></tr>");
			}

			pw.println("</table></center>");
			pw.println("<br/><br/><br/><center><a href=Welcomeadmin.jsp>Click here to go back</a></center>");
			pw.close();
			rs.close();st.close();con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void userLogin(HttpServletRequest request,
			HttpServletResponse response) {
		PrintWriter pw;
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String name=null;
		try {
			pw = response.getWriter();

			Login cl=new Login();
			String uid=request.getParameter("lid");
			String pwd=request.getParameter("pwd");
			cl.setUser_id(uid);
			cl.setPassword(pwd);
			LoginValidateImpl lv=new LoginValidateImpl();
			HttpSession hs=request.getSession();
			String val=lv.userLogin(cl);
			System.out.println(uid+"  is Going to login");
			if(val.equalsIgnoreCase("valid")){
				System.out.println(uid+"  is logged in");
				hs.setAttribute("cid", request.getParameter("lid"));
				JdbcConnection db=new JdbcConnection();
				con=db.getConnection();
				pst=con.prepareStatement("select custname from userdetail where Customerid=?");
				pst.setString(1,cl.getUser_id() );
				rs=pst.executeQuery();
				if(rs.next()){

					name=rs.getString(1);
					hs.setAttribute("cname",name);
					RequestDispatcher rd=request.getRequestDispatcher("Welcomecustomer.jsp");
					rd.forward(request, response);
				}
				else{
					pw.println("<font color=red>* Customer not found.Please relogin</font>");
					RequestDispatcher rd=request.getRequestDispatcher("Customerlogin.jsp");
					rd.include(request, response);
				}

			}
			else{
				pw.println("<font color=red>* Invalid loginid / password </font>");
				RequestDispatcher rd=request.getRequestDispatcher("Customerlogin.jsp");
				rd.include(request, response);
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void register(HttpServletRequest request,
			HttpServletResponse response) {

		try {
			pw = response.getWriter();
			String cid=(request.getParameter("cid"));
			String name=request.getParameter("cname");
			String email=request.getParameter("email");
			int mobno=Integer.parseInt(request.getParameter("cno"));
			String pw1=request.getParameter("pwd");
			String pw2=request.getParameter("pwd1");

			if(pw1.equals(pw2)){
				
				Customer c=new Customer(mobno,cid,name,email);
				RegisterImpl r=new RegisterImpl();
				String val=r.register(c);
				if(val.equals("found")){
					Registercustomer rc=new Registercustomer();
					int s=rc.register(c,pw1);
					if(s==2){
						pw.println("Registered successfully");
						RequestDispatcher rd=request.getRequestDispatcher("Customerlogin.jsp");
						rd.include(request, response);
					}
					else{
						pw.println("<font color=red>* Error in registering..try again</font>");
						RequestDispatcher rd=request.getRequestDispatcher("Register.jsp");
						rd.include(request, response);
					}
				}
				else{
					pw.println("<font color=red>* Invalid card number</font>");
					RequestDispatcher rd=request.getRequestDispatcher("Register.jsp");
					rd.include(request, response);
				}
			}
			else{
				pw.println("<font color=red>* Password didnt match</font>");
				RequestDispatcher rd=request.getRequestDispatcher("Register.jsp");
				rd.include(request, response);
			}

			pw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void adminLogin(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession hs=request.getSession();
		Login al=new Login();
		String uid=request.getParameter("lid");
		String pwd=request.getParameter("pwd");
		al.setUser_id(uid);
		al.setPassword(pwd);
		LoginValidateImpl lv=new LoginValidateImpl();

		String val=lv.adminLogin(al);


		try {
			pw = response.getWriter();	
			if(val.equalsIgnoreCase("valid"))
			{
				hs.setAttribute("admin", uid);	
				RequestDispatcher rd=request.getRequestDispatcher("Welcomeadmin.jsp");
				rd.forward(request, response);

			}
			else{
				pw.println("<font color=red>* Invalid loginid/password </font>");
				RequestDispatcher rd=request.getRequestDispatcher("Adminlogin.jsp");
				rd.include(request, response);
			}	

			pw.close();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}

	private void viewCard(HttpServletRequest request,
			HttpServletResponse response) {
		Connection con;
		Statement st;
		ResultSet rs;
		HttpSession hs=request.getSession();
		JdbcConnection db=new JdbcConnection();
		con=db.getConnection();
		try {
			pw=response.getWriter();
			st=con.createStatement();
			rs=st.executeQuery("select * from creditcards");
			pw.println("<body bgcolor=lightblue>");
			pw.println("<div><center><font size=6 color=blue>GLOBAL BANK</font><br/><font size=4 color=black><b><u>CREDIT CARD MANAGEMENT</u></b></font></div>");

			
			pw.println("<br/><br/><br/><center><font size=4>Logged in as admin "+hs.getAttribute("admin")+"</font></center><br/><br/><br/>");
			pw.println("<br/><br/><center><h3><u>CARD DETAILS</u></h3>");
			pw.println("<table border=1><tr><th>CARD NUMBER</th><th>PLAN</th><th>EXPIRY DATE</th><th>CVV</th><th>Status of Card</th></tr>");
			while(rs.next()){
				pw.println("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(4)+"</td><td>"+rs.getInt(3)+"</td><td>  "+rs.getString(5)+"</td></tr>");
			}

			pw.println("</table></center></body>");
			pw.println("<br/><br/><br/><center><a href=Welcomeadmin.jsp>Click here to go back</a></center>");
			pw.close();
			rs.close();st.close();con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}


	private void addTrans(HttpServletRequest request,
			HttpServletResponse response) {
		
			
		String tid=request.getParameter("tid");
		
		String cid=request.getParameter("cid");
		String vendor=request.getParameter("vendor");
		int amt=Integer.parseInt(request.getParameter("amt"));
		String loc=request.getParameter("loc");
		String cno=request.getParameter("cno");
		String plan=request.getParameter("plan");
        String tdate=request.getParameter("date");

		try {
			pw=response.getWriter();
			
			

			Transaction ts=new Transaction(tid,vendor,cno,tdate,loc,amt,cid,plan);
			System.out.println("Values of transaction stored successfully\n\n");
			TransactionValidateImpl tv=new TransactionValidateImpl();
			int res=tv.addTransaction(ts);
			if(res==2){
				Transactionadmin td=new Transactionadmin();
				int n=td.AddTransaction(ts);
				if(n>0){
					pw.println("<font color=yellow size=5>Added successfully.....</font>");
					RequestDispatcher rd=request.getRequestDispatcher("Addtransaction.jsp");
					rd.include(request, response);
				}else{
					pw.println("<font color=red size=5>* Credit limit exceeded .....</font>");
					RequestDispatcher rd=request.getRequestDispatcher("Addtransaction.jsp");
					rd.include(request, response);
				}
			}else{
				pw.println("<font color=red size=5>*Invalid data.....</font>");
				RequestDispatcher rd=request.getRequestDispatcher("Addtransaction.jsp");
				rd.include(request, response);
				
			}

//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}


	private void modTrans(HttpServletRequest request,
			HttpServletResponse response) {
		String tid=request.getParameter("tid");
		String col=request.getParameter("select");
		String val=request.getParameter("value");
		TransactionValidateImpl tv=new TransactionValidateImpl();
		String res=tv.checkTransaction(tid);

		try {
			pw=response.getWriter();
			if(res.equals("valid")){
				Transactionadmin td=new Transactionadmin();
				int result=td.ModifyTransaction(tid, col, val);
				if(result>0){
					pw.println("<font color=white size=5>Updated successfully.....</font>");
					RequestDispatcher rd=request.getRequestDispatcher("Modifytransaction.jsp");
					rd.include(request, response);
				}else{
					pw.println("<font color=red size=5>* Credit limit exceeded...</font>");
					RequestDispatcher rd=request.getRequestDispatcher("Modifytransaction.jsp");
					rd.include(request, response);
				}
			}
			else{
				pw.println("<font color=red size=5>* Invalid data...</font>");
				RequestDispatcher rd=request.getRequestDispatcher("Modifytransaction.jsp");
				rd.include(request, response);
				
			}} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}




	}


	private void delTrans(HttpServletRequest request,
			HttpServletResponse response) {
		String tid=request.getParameter("tid");
		TransactionValidateImpl tv=new TransactionValidateImpl();
		String res=tv.checkTransaction(tid);

		try {
			pw=response.getWriter();
			if(res.equals("valid")){
				Transactionadmin td=new Transactionadmin();
				int result=td.DeleteTransaction(tid);
				if(result>0){
					pw.println("<font color=yellow size=5>Deleted successfully.....</font>");
					RequestDispatcher rd=request.getRequestDispatcher("Deletetransaction.jsp");
					rd.include(request, response);
				}
				else{
					pw.println("<font color=white size=5>Error.....</font>");
					RequestDispatcher rd=request.getRequestDispatcher("Deletetransaction.jsp");
					rd.include(request, response);
					
				}}else{
					pw.println("<font color=white size=5>Invalid Transaction id.....</font>");
					RequestDispatcher rd=request.getRequestDispatcher("Deletetransaction.jsp");
					rd.include(request, response);
					
				}} catch (ServletException e) {
				
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


	}	

	private void getBill(HttpServletRequest request,
			HttpServletResponse response) {

		HttpSession hs=request.getSession();
		String custid=(String) hs.getAttribute("cid");

		GenerateBillImpl gbi=new GenerateBillImpl();
		System.out.println("In getbill For generate billimpl");
		Bill b=gbi.genBill(custid);
		try {
			if(b!=null){
				hs.setAttribute("bill", b);	
				RequestDispatcher rd=request.getRequestDispatcher("GetBill.jsp");				
				rd.forward(request, response);
			}} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}


	private void transUser(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession hs=request.getSession();
		String custid=(String) hs.getAttribute("cid");
		String value=request.getParameter("radio1");
		String name=request.getParameter("value");

		SearchTrans st=new SearchTrans();
		st.setColumn(value);
		st.setValue(name);

		TransUserimpl tu=new TransUserimpl();

		ArrayList<Transaction> at=new ArrayList<Transaction>();
		at=tu.userTrans(custid,st);
		try {
			pw=response.getWriter();
			if(at!=null){
				hs.setAttribute("usertransaction", at);
				RequestDispatcher rd=request.getRequestDispatcher("MyTransaction.jsp");				
				rd.forward(request, response);
			}else{
				pw.println("Error...");
			}
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}






