package DdlDmlpack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import beans.JdbcConnection;
import beans.SearchTrans;
import beans.Transaction;

public class TransUserimpl implements TransactionUser{
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	JdbcConnection db=new JdbcConnection();

	
	
	public ArrayList<Transaction> userTrans(String id,SearchTrans st) {
		
		String cid=id;
		ArrayList<Transaction> at=new ArrayList<Transaction>();
		con=db.getConnection();
		
		String colname=st.getColumn();
		String colvalue=st.getValue();
		
		if(colname.equals("transbyid")){
			System.out.println(id);
		try {
			pst=con.prepareStatement("select * from transaction where customerid=? and transactionid=?");
			pst.setString(1, cid);
			pst.setString(2, colvalue);
			rs=pst.executeQuery();
			while(rs.next()){
				Transaction ts=new Transaction(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6),rs.getString(7),rs.getString(8));
				at.add(ts);			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
			
		}

		if(colname.equals("transbylocation")){
			
			
		try {
			pst=con.prepareStatement("select * from transaction where customerid=? and location=?");
			pst.setString(1, cid);
			pst.setString(2, colvalue);
			rs=pst.executeQuery();
			while(rs.next()){
				Transaction ts=new Transaction(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6),rs.getString(7),rs.getString(8));
				at.add(ts);			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
			
		}
		if(colname.equals("transbyvendor")){
			
			
			try {
				pst=con.prepareStatement("select * from TransactionInfo where customerid=? and vendor=?");
				pst.setString(1, cid);
				pst.setString(2, colvalue);
				rs=pst.executeQuery();
				while(rs.next()){
					Transaction ts=new Transaction(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6),rs.getString(7),rs.getString(8));
					at.add(ts);			
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
				
			}
if(colname.equals("transbydate")){
	
			try {
				SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date date = formatter.parse(colvalue);
				java.sql.Date tdate = new java.sql.Date(date.getTime()); 
						System.out.println(tdate);
				pst=con.prepareStatement("select * from transaction where customerid=? and transdate=?");
				pst.setString(1, cid);
				pst.setString(2, colvalue);
				rs=pst.executeQuery();
				while(rs.next()){
					Transaction ts=new Transaction(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6),rs.getString(7),rs.getString(8));
					at.add(ts);			
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
				
			}
if(colname.equals("transall")){
	
	
	try {
		pst=con.prepareStatement("select * from transaction where customerid=?");
		pst.setString(1, cid);
		rs=pst.executeQuery();
		while(rs.next()){
			Transaction ts=new Transaction(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6),rs.getString(7),rs.getString(8));
			at.add(ts);			
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
		
	}
		
		
		return at;
	}
	

}
