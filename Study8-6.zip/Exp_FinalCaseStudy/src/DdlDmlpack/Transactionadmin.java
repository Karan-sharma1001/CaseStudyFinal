package DdlDmlpack;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import beans.JdbcConnection;
import beans.Transaction;

public class Transactionadmin implements TransactionAdminInterface{
	Connection con;
	PreparedStatement pst;
	CallableStatement cst;
	ResultSet rs;
	JdbcConnection db=new JdbcConnection();
	

	public double checkLimit(String plan) {
		double limit=0;
		if(plan.equals("platinum")){
			limit=75000;
		}else if(plan.equals("gold")){
			limit=60000;
		}else if(plan.equals("silver")){
			limit=50000;
		}
		return limit;
	}
	

	public int AddTransaction(Transaction ts) {
		int res=0;
		
		double total;
		
		double limit=checkLimit(ts.getPlan());
		
		String cid=ts.getCustid();
		
		try {
			
			con=db.getConnection();
			
			cst=con.prepareCall("{call billamount(?,?)}");
			
			cst.setString(1, cid);
			cst.registerOutParameter(2, Types.INTEGER);
			
			cst.executeUpdate();
			
			total=cst.getInt(2);
			
			if(total>=limit){
				
				res=0;
				cst.close();
				con.close();
				
			}else{
				
			pst=con.prepareStatement("insert into transactioninfo values(?,?,?,?,?,?,?,?)");
			
			pst.setString(1,ts.getTransid());
			pst.setString(7, ts.getCustid());
			pst.setString(2, ts.getVendor());
			pst.setInt(6, ts.getTransamount());
			pst.setString(4, ts.getTdate());
			pst.setString(5,ts.getLoc());
			pst.setString(3, ts.getCardno());
			pst.setString(8, ts.getPlan());
			
			res=pst.executeUpdate();
			
			pst.close();
			con.close();}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return res;
	}


	public int DeleteTransaction(String id) {
		con=db.getConnection();
		int s=0;
		try {
			pst=con.prepareStatement("delete from transactioninfo where transactionsid=?");
			pst.setString(1, id);
			s=pst.executeUpdate();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return s;
	}


	public int ModifyTransaction(String id,String col,String val){
		con=db.getConnection();
		int r=0;
		if(col.equalsIgnoreCase("Vendor")){
			try {
				pst=con.prepareStatement("update transactioninfo set vendor=? where transactionid=?");
				pst.setString(1, val);
				pst.setString(2, id);
				r=pst.executeUpdate();
				pst.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		if(col.equalsIgnoreCase("Transamount")){
			int value=Integer.parseInt(val);
			String plan=null;
			double limit=0;
			double total=0;
			String cid="N/A";
			int amt=0;
			try {
				pst=con.prepareStatement("select customerid,plan,transamount from transactioninfo where transactionid=?");
				pst.setString(1, id);
				rs=pst.executeQuery();
				if(rs.next()){
					cid=rs.getString(1);
					plan=rs.getString(2);
					amt=rs.getInt(3);
				}
				limit=checkLimit(plan);
				rs.close();pst.close();
				
				cst=con.prepareCall("{call billamount(?,?)}");
				cst.setString(1,cid);
				cst.registerOutParameter(2, Types.INTEGER);
				cst.executeUpdate();	
				total=cst.getInt(2);
				if(total>=limit){
					if(value>amt){
					r=0;
						}else{
							pst=con.prepareStatement("update transactioninfo set transamount=? where transactionid=?");
							pst.setInt(1, value);
							pst.setString(2, id);
							r=pst.executeUpdate();
							pst.close();
							
						}
					}else{

				pst=con.prepareStatement("update transactioninfo set transamount=? where transactionid=?");
				pst.setInt(1, value);
				pst.setString(2, id);
				r=pst.executeUpdate();
				pst.close();}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		if(col.equals("Transdate")){
			try {
				
				//SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
            	//java.util.Date date = formatter.parse(val);
            	//java.sql.Date dt= new java.sql.Date(date.getTime()); 
            	
				pst=con.prepareStatement("update transactioninfo set transdate=? where transactionid=?");
				pst.setString(1, val);
				pst.setString(2, id);
				r=pst.executeUpdate();
				pst.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		if(col.equals("Location")){
			try {
				pst=con.prepareStatement("update transactioninfo set location=? where transactionid=?");
				pst.setString(1, val);
				pst.setString(2, id);
				r=pst.executeUpdate();
				pst.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return r;
	}


	public ArrayList<Transaction> SearchTrans(beans.SearchTrans st) {
		ArrayList<Transaction> at=new ArrayList<Transaction>();
		con=db.getConnection();
		String colname=st.getColumn();
		String colvalue=st.getValue();
		
		if(colname.equals("transbyuser")){
			String id=colvalue;
			System.out.println(id);
		try {
			pst=con.prepareStatement("select * from transactioninfo where customerid=?");
			pst.setString(1, id);
			rs=pst.executeQuery();
			while(rs.next()){
				Transaction ts=new Transaction(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6),rs.getString(7),rs.getString(8));
				at.add(ts);			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
			
		}

		if(colname.equals("transbylocation")){
			
			
		try {
			pst=con.prepareStatement("select * from transactioninfo where location=?");
			pst.setString(1, colvalue);
			rs=pst.executeQuery();
			while(rs.next()){
				Transaction ts=new Transaction(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6),rs.getString(7),rs.getString(8));
				at.add(ts);			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
			
		}
		if(colname.equals("transbyvendor")){
			
			
			try {
				pst=con.prepareStatement("select * from transactioninfo where vendor=?");
				pst.setString(1, colvalue);
				rs=pst.executeQuery();
				while(rs.next()){
					Transaction ts=new Transaction(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6),rs.getString(7),rs.getString(8));
					at.add(ts);			
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
				
			}
if(colname.equals("transbydate")){
	
			try {
				SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date date = formatter.parse(colvalue);
				java.sql.Date tdate = new java.sql.Date(date.getTime()); 
						
				pst=con.prepareStatement("select * from transactioninfo where transdate=?");
				pst.setString(1, colvalue);
				rs=pst.executeQuery();
				while(rs.next()){
					Transaction ts=new Transaction(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6),rs.getString(7),rs.getString(8));
					at.add(ts);			
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
				
			}
if(colname.equals("transall")){
	
	
	try {
		pst=con.prepareStatement("select * from transactioninfo");
		rs=pst.executeQuery();
		while(rs.next()){
			Transaction ts=new Transaction(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6),rs.getString(7),rs.getString(8));
			at.add(ts);			
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
		
	}
		
		
		return at;
	}

	
	

}
