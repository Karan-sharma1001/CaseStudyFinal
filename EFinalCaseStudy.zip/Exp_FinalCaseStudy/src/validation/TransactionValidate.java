package validation;

import beans.Transaction;

public interface TransactionValidate {
	
	public int addTransaction(Transaction ts);
	public String checkTransaction(String id);


}
